run Ranger.exe to run Toranger.
Ranger is a shell program for Toranger.

specifically, the "Clean Cache" button is the way to set Tor cache clear. you may
try this out while Toranger "probably" can not get through the firewall or cencorship, then 
try "Run" again.

if you get process bar stuck for a very long time, please try "Tor Stop" or use 
"clean cache" and try again.

default port is 9050, for socks 5
to use 8118 http protocal, run http_protocal.bat after Tor's running successful.

9.2.2013