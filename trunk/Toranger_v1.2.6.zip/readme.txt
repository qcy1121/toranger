tor_single_run.bat : run Toranger
http_protocal.bat: run polipo protocal transfer

set proxy as:

127.0.0.1

port: 8118 for http protocal,  9050 for socks 5 protocal.

9050 is default port.
to use 8118 http protocal you need run http_protocal.bat as well.